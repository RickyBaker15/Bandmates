document.addEventListener('DOMContentLoaded', () => {
    const conversationList = document.getElementById('conversation-list');
    const chatMessages = document.getElementById('chat-messages');
    const messageForm = document.getElementById('message-form');
    const messageInput = document.getElementById('message-input');
    const currentChatUser = document.getElementById('current-chat-user');

    // Dummy data for conversations with temporary users
    const conversations = [
        { userId: 1, userName: 'John Doe' },
        { userId: 2, userName: 'Jane Smith' },
        { userId: 3, userName: 'Mike Johnson' },
        { userId: 4, userName: 'Temporary User 1' },
        { userId: 5, userName: 'Temporary User 2' }
    ];

    // Simulated messages data (replace with actual messages from server)
    const messages = {
        1: [
            { sender: 'John Doe', text: 'Hello!' },
            { sender: 'John Doe', text: 'How are you?' }
        ],
        2: [
            { sender: 'Jane Smith', text: 'Hi there!' },
            { sender: 'Jane Smith', text: 'Nice to meet you!' }
        ],
        3: [
            { sender: 'Mike Johnson', text: 'Hey!' }
        ],
        4: [
            { sender: 'Temporary User 1', text: 'Hello from Temporary User 1!' }
        ],
        5: [
            { sender: 'Temporary User 2', text: 'Hi from Temporary User 2!' },
            { sender: 'Temporary User 2', text: 'How can I help?' }
        ]
    };

    // Display conversations in the sidebar
    conversations.forEach(conversation => {
        const li = document.createElement('li');
        li.textContent = conversation.userName;
        li.setAttribute('data-user-id', conversation.userId);
        conversationList.appendChild(li);
    });

    // Function to load chat messages for a selected user
    function loadChatMessages(userId) {
        chatMessages.innerHTML = ''; // Clear previous messages
        const userMessages = messages[userId] || [];

        userMessages.forEach(message => {
            const messageDiv = createMessageElement(message);
            chatMessages.appendChild(messageDiv);
        });

        // Update current chat user in the chat header
        const selectedUser = conversations.find(user => user.userId == userId);
        if (selectedUser) {
            currentChatUser.textContent = selectedUser.userName;
        }
    }

    // Function to create a message element
    function createMessageElement(message) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message');
        messageDiv.textContent = `${message.sender}: ${message.text}`;
        return messageDiv;
    }

    // Event listener for conversation item click
    conversationList.addEventListener('click', (e) => {
        if (e.target.tagName === 'LI') {
            const selectedUserId = e.target.getAttribute('data-user-id');
            loadChatMessages(selectedUserId);
        }
    });

    // Event listener for message form submission
    messageForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const messageText = messageInput.value.trim();
        if (messageText === '') return;

        const selectedUserId = getCurrentChatUserId();
        if (!selectedUserId) return;

        const newMessage = {
            sender: 'You', // Assuming current user is sending the message
            text: messageText
        };

        // Create and append new message element to chat area
        const messageDiv = createMessageElement(newMessage);
        chatMessages.appendChild(messageDiv);

        // Clear the message input field after sending
        messageInput.value = '';

        // Scroll to the bottom of chat area
        chatMessages.scrollTop = chatMessages.scrollHeight;

        // Simulate sending message (not implemented in this example)
        // Here you would send the message data to a server for storage
        // and potentially receive a response with updated messages
        // from the server to keep the chat in sync with other users.
    });

    // Function to get the currently selected chat user ID
    function getCurrentChatUserId() {
        const selectedUser = conversationList.querySelector('li.active');
        return selectedUser ? selectedUser.getAttribute('data-user-id') : null;
    }
});
