document.addEventListener('DOMContentLoaded', () => {
    const editBtn = document.getElementById('edit-btn');
    const editForm = document.getElementById('edit-form');
    const profileInfo = document.getElementById('profile-info');
    const profileForm = document.getElementById('profile-form');
    const cancelBtn = document.getElementById('cancel-btn');

    editBtn.addEventListener('click', () => {
        // Hide profile info, show edit form
        profileInfo.style.display = 'none';
        editForm.style.display = 'block';

        // Pre-fill form fields with current profile info
        const nameInput = document.getElementById('name');
        const emailInput = document.getElementById('email');
        const usernameInput = document.getElementById('username');
        const genresInput = document.getElementById('genres');

        nameInput.value = 'John Doe'; // Replace with actual user data
        emailInput.value = 'johndoe@example.com';
        usernameInput.value = 'johndoe123';
        genresInput.value = 'Rock, Jazz, Blues';
    });

    cancelBtn.addEventListener('click', () => {
        // Show profile info, hide edit form
        profileInfo.style.display = 'block';
        editForm.style.display = 'none';
    });

    profileForm.addEventListener('submit', (e) => {
        e.preventDefault();
        // Handle form submission (e.g., send data to server)
        // Here, you would typically make an AJAX request to update user info
        // Display success message or handle errors
        console.log('Form submitted!');
        // For demonstration purposes, reset form and hide edit form
        profileInfo.style.display = 'block';
        editForm.style.display = 'none';
    });
});
